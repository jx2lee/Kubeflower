This directory contains some additional configuration files that are used by some KFDef resources
when deploying with kfctl.